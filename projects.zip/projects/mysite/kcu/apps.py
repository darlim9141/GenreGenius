from django.apps import AppConfig


class KcuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kcu'
